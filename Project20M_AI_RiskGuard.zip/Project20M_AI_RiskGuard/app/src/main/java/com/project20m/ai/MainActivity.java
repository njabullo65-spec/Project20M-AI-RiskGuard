package com.project20m.ai;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    EditText oddsInput, probInput, matchInput;
    TextView resultTitle, resultText;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        matchInput = findViewById(R.id.matchInput);
        oddsInput = findViewById(R.id.oddsInput);
        probInput = findViewById(R.id.probInput);
        resultTitle = findViewById(R.id.resultTitle);
        resultText = findViewById(R.id.resultText);

        findViewById(R.id.analyzeButton).setOnClickListener(v -> analyze());
    }

    private void analyze() {
        String match = matchInput.getText().toString().trim();
        try {
            double odds = Double.parseDouble(oddsInput.getText().toString());
            double probability = Double.parseDouble(probInput.getText().toString());

            if (odds <= 1.0 || probability < 0 || probability > 100) {
                resultTitle.setText("Check your inputs");
                resultText.setText("Odds must be above 1.00 and probability must be between 0 and 100.");
                return;
            }

            double implied = 100.0 / odds;
            double edge = probability - implied;

            String risk;
            if (probability < 45 || odds >= 4.0) risk = "🔴 VERY HIGH RISK";
            else if (probability < 55 || odds >= 2.5) risk = "🟠 HIGH RISK";
            else if (probability < 65 || odds >= 1.9) risk = "🟡 MODERATE RISK";
            else risk = "🟢 LOWER RISK";

            String name = match.isEmpty() ? "Selected market" : match;
            resultTitle.setText(risk);
            resultText.setText(
                name + "\n\n" +
                "Estimated probability: " + fmt(probability) + "%\n" +
                "Market implied probability: " + fmt(implied) + "%\n" +
                "Difference: " + (edge >= 0 ? "+" : "") + fmt(edge) + " percentage points\n\n" +
                "RiskGuard is an educational estimate, not a prediction guarantee."
            );
        } catch (Exception e) {
            resultTitle.setText("Enter valid numbers");
            resultText.setText("Example: odds 1.75 and probability 61.");
        }
    }

    private String fmt(double x) {
        return String.format(java.util.Locale.US, "%.1f", x);
    }
}
