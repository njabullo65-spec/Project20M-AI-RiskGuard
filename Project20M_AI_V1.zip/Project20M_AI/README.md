# Project20M AI — Version 1

Android Java starter project with:
- RiskGuard risk indicators
- Odds/implied-probability calculation
- Estimated probability comparison
- Demo/educational design
- No automatic betting or guaranteed-win claims

Open the folder as an Android Studio/compatible Gradle Android project and build the APK.
